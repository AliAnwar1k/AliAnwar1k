/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.management.system;

import java.sql.*;

public class conn {
    Connection c;
    Statement s;

    public conn() {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection with the database
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "123456");

            // Create a statement object
            s = c.createStatement();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}


