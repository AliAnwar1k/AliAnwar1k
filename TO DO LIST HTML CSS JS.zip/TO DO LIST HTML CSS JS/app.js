const addForm = document.querySelector(".add"); // reference to form
const list = document.querySelector(".todos"); // reference to ul

// Adding todos
const generateTemplate = (todo) => {
  const html = `
   <li class="list-group-item d-flex justify-content-between align-items-center">
      <span>${todo}</span>
      <i class="fa fa-trash-o delete"></i>
   </li>
  `;
  list.innerHTML += html;
};

addForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const todo = addForm.add.value.trim();

  if (todo.length) {
    generateTemplate(todo);
    addForm.reset();
  }
});

// Deleting todos - event delegation
list.addEventListener("click", (e) => {
  if (e.target.classList.contains("delete")) {
    e.target.parentElement.remove();
  }
});

// Filter and Searching - keyup event
const search = document.querySelector(".input-field");

const filterTodos = (term) => {
  Array.from(list.children).forEach((todo) => {
    const todoText = todo.textContent.toLowerCase();
    if (todoText.includes(term)) {
      todo.classList.remove("filtered");
    } else {
      todo.classList.add("filtered");
    }
  });
};

search.addEventListener("keyup", () => {
  const term = search.value.trim().toLowerCase();
  filterTodos(term);
});
